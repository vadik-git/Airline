﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DAL;
using DAL.Models;

namespace UI_2
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        FlightService data = new FlightService();
        public MainWindow()
        {
            InitializeComponent();
          
            btn.IsEnabled = false;
            dataGrid.ItemsSource = data.GetAllFlights().Select(f => new
            {
                Number = f.Number,
                Time = f.DepartureTime,
                AirplaneModel = f.Airplane.Model,
                From = f.CityFrom.Name,
                To = f.CityTo.Name
            }).ToList();
        }


        

        private void Btn_Click(object sender, RoutedEventArgs e)
        {

            
           
            dataGrid.ItemsSource = data.Find(cbCityFrom.Text).Select(f => new
            {
                Number = f.Number,
                Time = f.DepartureTime,
                AirplaneModel = f.Airplane.Model,
                From = f.CityFrom.Name,
                To = f.CityTo.Name
            }).ToList();


        }

        private void CbCityFrom_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (cbCityFrom.Text != null)
            {
                btn.IsEnabled = true;
            }
            else if (cbCityFrom.Text==null)
            {
                btn.IsEnabled = false;
            }

        }
    }
}
