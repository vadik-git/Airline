﻿using DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class FlightService
    {
        private AirlinesDbContext data;
        public FlightService()
        {
            data = new AirlinesDbContext();
        }

        // TODO: Write methods for find flights
        public IQueryable<Flight> GetAllFlights()
        {
            return data.Flights;
        }
       
        public List<Flight> getfl()
        {
            return data.Flights.ToList();
        }
        public IQueryable<Flight> Find(string place)
        {
            return data.Flights.Where(f => f.CityFrom.Name == place);
            /// зделав тільки по місту
            /// бо дата не збігається чомусь хоча запит правильний
            /// return data.Flights.Where(f => f.DepartureTime == date).Where(f => f.CityTo.Name == place);


        }


    }
}
